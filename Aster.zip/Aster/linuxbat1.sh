go run main.go -n 0 -N 1 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 0 --fnum 1 &

go run main.go -n 0 -N 1 -s 0 -S 1 -m 3 -p 1 --pid 0 --fnum 1 &