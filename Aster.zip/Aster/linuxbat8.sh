go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 0 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 1 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 2 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 3 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 4 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 5 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 6 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 7 --fnum 8 &

go run main.go -n 0 -N 8 -s 0 -S 1 -m 3 -p 1 --pid 0 --fnum 8 &


