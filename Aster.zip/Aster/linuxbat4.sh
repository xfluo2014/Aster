go run main.go -n 0 -N 4 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 0 --fnum 4 &

go run main.go -n 0 -N 4 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 1 --fnum 4 &

go run main.go -n 0 -N 4 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 2 --fnum 4 &

go run main.go -n 0 -N 4 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 3 --fnum 4 &

go run main.go -n 0 -N 4 -s 0 -S 1 -m 3 -p 1 --pid 0 --fnum 4 &


