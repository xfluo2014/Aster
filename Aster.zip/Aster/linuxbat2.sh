go run main.go -n 0 -N 2 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 0 --fnum 2 &

go run main.go -n 0 -N 2 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 1 --fnum 2 &

go run main.go -n 0 -N 2 -s 0 -S 1 -m 3 -p 1 --pid 0 --fnum 2 &


