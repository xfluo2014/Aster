go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 0 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 1 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 2 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 3 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 4 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 5 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 6 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 7 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 8 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 9 --fnum 12 &

go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 10 --fnum 12 &
go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 -F --pid 0 --fid 11 --fnum 12 &


go run main.go -n 0 -N 12 -s 0 -S 1 -m 3 -p 1 --pid 0 --fnum 12 &


