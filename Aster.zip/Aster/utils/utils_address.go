package utils

type Address = string
