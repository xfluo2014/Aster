# BrokerFi func. 

本文档记录一些关于 brokerFi 的函数使用。

## 客户端 / 钱包端
``./client/client.go`` 内，客户端目前有如下函数：

- ``clientGenerateTx`` 客户端生成 Tx，**这个函数可以重写**，因为目前是把 Tx 写死的。
- ``SendTx2Worker`` 客户端把 Tx 发送给 Worker 分片。
- ``SendTxProofRequest2Worker`` 客户端向 Worker 分片询问某笔 Tx 是否上链，如果上链的话需要 MPT Proof 作为证明。传入 **TxHash**
- ``SendAccountStateRequest2Worker`` 客户端向 Worker 分片查询某个账户的状态，暂无 Proof。传入 **账户地址**


``./client/clientTcpLn.go`` 内，客户端对于接收到的消息（目前共两种）做出处理：

- ``handleTxOnChainProof`` 处理 Tx 是否上链的消息，对应函数 ``SendTxProofRequest2Worker``。
- ``handleAccountStateMsg`` 处理 账户状态 的消息，对应函数 ``SendAccountStateRequest2Worker``。

## Worker 端
``clientMsgHandler.go`` 内，Worker 节点对 Client 发出的消息做出响应。

- ``SendProofMsg`` 发送 Proof 消息。
- ``handleClientTxSend`` 处理 Client 端发送的 Tx。
- ``handleClientRequestTxProof`` 处理 Client 端发送的 Tx 上链查询，如果上链，提供 MPT Proof 作为证明。
- ``handleRequestAccountState`` 处理 Client 端发送的账户状态查询。